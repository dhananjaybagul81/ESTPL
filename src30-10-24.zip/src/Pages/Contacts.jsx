import React from 'react';

const Contact = () => {
  return (
    <>
      <div className="flex h-full bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto relative">
        
        
        <div className="flex-1 p-10 flex flex-col justify-start">
          <h1 className="text-6xl font-bold leading-tight">
            Our development skills are <br /> at your disposal - <br /> wherever you are.
          </h1>
        </div>

        
        <div className="flex flex-col mt-40 w-[40vw]  p-10 absolute right-4">
         
          <div className="flex justify-between items-center">
            <p className="text-lg  p-4">
              Fill out our form and we will <br /> contact you in the next 24 hours.
            </p>
            <button className="ml-10 w-[10vw] bg-red-600 text-white font-bold py-2 px-4 rounded hover:bg-red-900 transition duration-300">
              Contact Us
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
