import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  const [activeTab, setActiveTab] = useState(0);
  const tabs = [
    { name: 'About', path: '/about' },
      
    { name: 'Industries', path: '/industries' },
    { name: 'Services', path: '/service' }, 
    { name: 'Blog', path: '/blog' },
    { name: 'Case studies', path: '/Casestudies' },
    { name: 'Careers', path: '/careers' },
    { name: 'Contacts', path: '/contact' },
  ];

  return (
    <header className="bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto">
      <div className="mt-10 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          
          {/* Logo section */}
          <div className="flex items-center">
          <Link to="/" className="text-4xl font-bold text-red-500">
              Estpl
            </Link>          
              <span className="mx-4 text-gray-500"></span>
          </div>

          <nav className="flex-grow flex justify-end">
            <ul className="flex items-center space-x-3">
              {tabs.map((tab, index) => (
                <React.Fragment key={tab.name}>
                  <li>
                    <Link
                      to={tab.path} // Use Link component to navigate to the route
                      className={`rounded-md text-md font-bold ${
                        activeTab === index
                          ? 'text-gray-900'
                          : 'text-black-900 hover:text-red-900'
                      }`}
                      onClick={() => setActiveTab(index)}
                    >
                      {tab.name}
                    </Link>
                  </li>
                
                  {index < tabs.length - 1 && (
                    <span className="text-gray-500">/</span>
                  )}
                </React.Fragment>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
