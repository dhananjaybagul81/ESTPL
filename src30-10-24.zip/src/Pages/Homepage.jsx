import React from 'react'

import Heroes from "../Components/Homepage/Heroes";
import Ourcross from '../Components/Homepage/Ourcross';
import Customer from '../Components/Homepage/Customer';
import Ourservices from '../Components/Homepage/Ourservices';
import Idea from '../Components/Homepage/Idea';
import Weoffer from '../Components/Homepage/Weoffer';
import Ourteam from '../Components/Homepage/Ourteam';
import Casestudy from '../Components/Homepage/Casestudy';
import Card from "../Components/Homepage/Card";
import Ourclient from '../Components/Homepage/Ourclient';
import Anything from '../Components/Homepage/Anything';
import Expertise from '../Components/Homepage/Expertise';
import Articals from '../Components/Homepage/Articals';
import Contactus from '../Components/Homepage/Footer';

const Homepage = () => {
  return (
  <>
    <Heroes/>
    <Ourcross/>
    <Customer/>
    <Ourservices/>
    <Idea/>
    <Weoffer/>
    <Ourteam/>
    <Casestudy/>
    <Card/>
    <Ourclient/>
    <Anything/>
    <Expertise/>
    <Articals/>
    {/* <Contactus/> */}
    
  
  </>
  )
}

export default Homepage;