import { Route, Router, Routes } from "react-router-dom";
import Header from "./Pages/Header";
import Homepage from "./Pages/Homepage";
import "./App.css"
import Service from "./Pages/Services"
import Footer from "../src/Components/Homepage/Footer";
import  Industries from "../src/Pages/Industries";
import  Contact from "../src/Pages/Contacts";
import Blog from "../src/Pages/Blog";
import Casestudies from "../src/Pages/Casestudies";
import Careers from "../src/Pages/Careers";
import About from "../src/Pages/About";

function App() {
  return (
    <>
   <Header />
      <Routes>
     
      <Route path="/" element={<Homepage />} />
      <Route path="/service" element={< Service/>}/>
      <Route path="/industries" element={< Industries/>}/>
      <Route path="/contact" element={< Contact/>}/>
      <Route path="/blog" element={<Blog/>}/>
      <Route path="/casestudies" element={< Casestudies/>}/>
      <Route path="/careers" element={< Careers/>}/>
      <Route path="/about" element={< About/>}/>
      {/* 
      
      
     
      <Route path="/service" element={< Service/>}/> */}

        
      </Routes>
      <Footer/>
    
     
    </>
  );
}

export default App;
