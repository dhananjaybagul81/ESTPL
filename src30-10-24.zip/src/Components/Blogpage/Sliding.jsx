import React from 'react';
import Img1 from "../../assets/Blogi1.png";
import Img2 from "../../assets/Blogi2.png";
import Img3 from "../../assets/Blogi3.png";
import Img4 from "../../assets/Blogi4.png";
import Img5 from "../../assets/Blogi5.png";
import Img6 from "../../assets/Blogi6.png";

const Sliding = () => {
  const details = [
    {
      title: 'AI-powered Development',
      description: 'Artificial intelligence is reshaping how the legal field is doing business. Learn how AI can improve workflows and save time and money for lawyers and their clients.',
      image: Img1,
      text: 'By Viktoriya Poligenko',
    },
    {
      title: 'Jamstack Deciphered!',
      description: 'You’ve probably heard the term "Jamstack" used a lot lately. Jamstack is a modern web development architecture, designed to provide better performance, more security, cheaper scaling costs, and a smoother developer experience.',
      image: Img2,
      text: 'By Viktoriya Poligenko',
    },
    {
      title: 'Speed Up Development',
      description: 'Discover how you can speed up development workflows with modern tools and techniques in web development.',
      image: Img3,
      text: 'By Akash Bhamare',
    },
    {
      title: 'LLMs: Areas of Excellence and Limitations',
      description: 'A deep dive into the areas of excellence and limitations of Large Language Models (LLMs), and how businesses can leverage them.',
      image: Img4,
      text: 'By Adity Rokade',
    },
    {
      title: 'Fixed Price or Dedicated Team?',
      description: 'Learn the benefits of choosing the right collaboration approach with a tech vendor for custom software development.',
      image: Img5,
      text: 'By Akash',
    },
    {
      title: 'Hacking Success with a Discovery Phase Done Right',
      description: 'Discover why the project discovery phase is crucial for the success of software development.',
      image: Img6,
      text: 'By Bhamare',
    }
  ];

  return (
    
      <div className="flex  bg-[#edf2f3] h-full w-11/12 max-w-[1600px] mx-auto mt-20 py-6'">
        <div className='grid grid-cols-3 w-full'>
          
         
          <div className='col-span-1 p-4 flex flex-col justify-start sticky top-0 h-[100vh]'>
            <ul className="text-left">
              <li className='text-red-500 font-bold'>/ all</li>
              <li className='mt-2 text-gray-800'>best practices</li>
              <li className='mt-2 text-gray-800'>great tools</li>
              <li className='mt-2 text-gray-800'>techsplaining</li>
              <li className='mt-2 text-gray-800'>project how-to's</li>
            </ul>

            <ul className='text-left mt-auto'>
              <p>The software that we build takes <br /> our clients to the next level!</p>
              <button className="bg-red-600 mt-4 text-white px-6 py-3 transition-transform transform hover:scale-105">
                BECOME OUR CLIENT
              </button>
            </ul>
          </div>

          {/* Right Side Scrollable Section */}
          <div className='col-span-2 p-4 overflow-y-auto'>
            {details.map((detail, index) => (
              <div key={index} className="grid grid-cols-2 gap-10 mb-32 mt-8 border-b pb-4">
                <div className="flex items-center justify-center">
                  <img src={detail.image} alt={detail.title} className='w-[70vw] h-[50vh] object-cover rounded-[30px]' />
                </div>
                <div className="flex flex-col justify-start">
                  <h1 className='text-[40px] font-bold mt-4'>{detail.title}</h1>
                  <p className='text-gray-700 mt-8'>{detail.description}</p>
                  <p className='text-sm text-gray-500 mt-20'>{detail.text}</p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    
  );
}

export default Sliding;
