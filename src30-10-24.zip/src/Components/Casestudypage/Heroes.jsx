import React from 'react'

const Heroes = () => {
    return (
       
            <div className="flex bg-[#edf2f3]  h-full w-11/12  max-w-[1600px] mx-auto">
                <div className="flex-1 p-10 flex flex-col justify-center  mt-20 ">
                    <h1 className="text-8xl font-bold leading-tight">
                        <span>Check out  Estpl <br /><span className='text-blue-500 leading-tight' >Case Studies</span>
                        </span>
                    </h1>

                </div>
            </div>
        
    )
}

export default Heroes;