import React from 'react';
import Img1 from "../../assets/Casei1.png";
import Img2 from "../../assets/Casei2.png";
import Img3 from "../../assets/Casei3.png";
import Img4 from "../../assets/Casei4.png";
import Img5 from "../../assets/Casei5.png";

const Sliding = () => {
    const details = [
        {
            title: 'MilePulse: game-changing upgrade for a truck dispatch service',
            description: 'Learn how we helped a truck dispatcher service increase productivity, streamline processes and increase revenue.',
            image: Img1,
            Button: 'SaaS Development',
            technologies: [
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
                { name: 'Pandas', icon: '📊' },
                { name: 'R', icon: '📈' },
            ],
        },
        {
            title: 'Merch38 - a B2B branded merch printing platform.',
            description: 'Service that helps businesses create, print, sell and ship custom merch via one simple to handle widget!',
            image: Img2,
            Button: 'SaaS Development',
            technologies: [
                { name: 'React', icon: '⚛️' },
                { name: 'Node.js', icon: '🌐' },
                { name: 'CSS', icon: '🎨' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },

            ],
        },
        {
            title: 'Slidenest presentation templates for every taste',
            description: 'Find, download, and customize pre-made presentation templates. With hundreds of different templates available, there is one to fit any presentation idea!',
            image: Img3,
            Button: 'SaaS Development',
            technologies: [
                { name: 'Flutter', icon: '📱' },
                { name: 'Kotlin', icon: '🌈' },
                { name: 'Swift', icon: '🍏' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },

            ],
        },
        {
            title: 'LLMs: Areas of Excellence and Limitations',
            description: 'A deep dive into the areas of excellence and limitations of Large Language Models (LLMs), and how businesses can leverage them.',
            image: Img4,
            Button: 'SaaS Development',
            technologies: [
                { name: 'AWS', icon: '☁️' },
                { name: 'Azure', icon: '🔵' },
                { name: 'Google Cloud', icon: '🌩️' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
            ],
        },
        {
            title: 'Custom illustration builder: from great idea to successful product!',
            description: 'A deep dive into the areas of excellence and limitations of Large Language Models (LLMs), and how businesses can leverage them.',
            image: Img5,
            Button: 'SaaS Development',
            technologies: [
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
                { name: 'Pandas', icon: '📊' },
                { name: 'R', icon: '📈' },
            ],
        },
    ];

    return (
        <div className="flex bg-[#edf2f3] h-full w-11/12 max-w-[1600px] mx-auto mt-20 py-6">
            <div className='grid grid-cols-3 w-full'>
                <div className='col-span-1 p-4 flex flex-col justify-start sticky top-0 h-[100vh]'>
                    <ul className="text-left">
                        <li className='text-red-500 font-bold'>/ all</li>
                    </ul>
                    <ul className='text-left mt-auto'>
                        <p>The software that we build takes <br /> our clients to the next level!</p>
                        <button className="bg-red-600 mt-4 text-white px-6 py-3 transition-transform transform hover:scale-105">
                            BECOME OUR CLIENT
                        </button>
                    </ul>
                </div>


                <div className='col-span-2 p-4 overflow-y-auto'>
                    {details.map((detail, index) => (
                        <div key={index} className="gap-10 mb-32 mt-8  pb-4">

                            <h1 className='text-[40px] font-bold mt-4 hover:text-red-500 transition-colors mb-10'>{detail.title}</h1>
                            <div className='flex  grid-flow-col gap-8 mt-4'>
                                <div className="flex items-center justify-center ">
                                    <img src={detail.image} alt={detail.title} className='w-[80vw] h-[60vh] object-cover rounded-[30px]' />
                                </div>
                                <div className="flex flex-col justify-start">

                                    <p className='text-gray-700 mt-8 '>{detail.description}</p>


                                    <p className='border border-black bg-white text-black text-lg
                                          px-4 py-2 w-[12vw] mt-10'>{detail.Button}</p>


                                    <div className='mt-40'>
                                        <ul className='flex flex-wrap mt-2'>
                                            {detail.technologies.map((tech, techIndex) => (
                                                <li key={techIndex} className='flex items-center'>
                                                    <span className='mr-2 text-4xl shadow-lg shadow-red-500'>{tech.icon}</span> {/* Add colored shadow */}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                </div>



                            </div>
                        </div>
                        
                    ))}
            </div>
        </div>
        </div >
    );
}

export default Sliding;
