import React from 'react';
import bgimg from "../../assets/Servicebg.png";

const Ourpartner = () => {
    return (

        <div className='bg-black'>
            <div className=" w-full max-w-[1600px] mx-auto">
                <div className='p-10 flex flex-col justify-start h-[100vh] border border-black'> 
                    <h1 className="text-6xl font-bold leading-tight text-left ml-8"> 
                        <span className='text-white'>Our entrusted <span className='text-pink-500'>partners</span></span>
                    </h1>
                    <img  src={bgimg} className=' p-5 mt-32'/>
                </div>
            </div>
        </div>
        
    );
}

export default Ourpartner;
