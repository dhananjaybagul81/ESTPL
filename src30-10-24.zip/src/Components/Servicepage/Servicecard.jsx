import React from 'react';
import Img1 from "../../assets/Service1.png";
import Img2 from "../../assets/Service2.png";
// import Img3 from "../../assets/Service3.png";
// import Img4 from "../../assets/Service4.png";
// import Img5 from "../../assets/Service5.png";
// import Img6 from "../../assets/Service6.png";
// import Img7 from "../../assets/Service7.png";

const Servicecard = () => {
    const services = [
        {
            title: 'AI-powered Development',
            description: 'Unlock limitless opportunities with AI-powered development. Embrace AI\'s capabilities, and watch your business undergo an exciting metamorphosis.',
            image: Img1,  
            technologies: [
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
                { name: 'Pandas', icon: '📊' },
                { name: 'R', icon: '📈' },
            ],
        },
        {
            title: 'Mobile development ',
            description: 'Create stunning and responsCreate interactive mobile apps and increase user engagement with our cross-platform mobile development services.ive websites with the latest web technologies.',
            image: Img2,  
            technologies: [
                { name: 'React', icon: '⚛️' },
                { name: 'Node.js', icon: '🌐' },
                { name: 'CSS', icon: '🎨' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
            ],
        },
        {
            title: 'Backend development',
            description: 'Build high-qualBuild a solid foundation for your product with secure APIs, efficient data management, cloud migration services, and battle-tested development engineers.ity mobile applications for both Android and iOS platforms.',
            image: Img2,  
            technologies: [
                { name: 'Flutter', icon: '📱' },
                { name: 'Kotlin', icon: '🌈' },
                { name: 'Swift', icon: '🍏' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
            ],
        },
        {
            title: 'Frontend development',
            description: 'Leverage cloud Bring the best-frontend practices to your project with sophisticated development solutions that improve your customers',
            image: Img2, 
            technologies: [
                { name: 'AWS', icon: '☁️' },
                { name: 'Azure', icon: '🔵' },
                { name: 'Google Cloud', icon: '🌩️' },
                { name: 'Python', icon: '🐍' },
                { name: 'TensorFlow', icon: '🧠' },
                { name: 'AWS', icon: '☁️' },
            ],
        },
        {
            title: 'Custom web development ',
            description: 'Transform your data into actionable insights with data sWork with a development team attuned to your business goals. We offer a full development cycle, and a scalable cross-functional team that supports your project at every stage.cience solutions.',
            image: Img2,  
            technologies: [
                { name: 'Python', icon: '🐍' },
                { name: 'Pandas', icon: '📊' },
                { name: 'R', icon: '📈' },
                { name: 'Shopify', icon: '🛒' },
                { name: 'Magento', icon: '💳' },
                { name: 'WooCommerce', icon: '🛍️' },
            ],
        },
        {
            title: 'Quality assurance services',
            description: 'Improve your products performance. Catch bugs and conversion blockers with our manual and automated QA services.',
            image: Img2, 
            technologies: [
                { name: 'Shopify', icon: '🛒' },
                { name: 'Magento', icon: '💳' },
                { name: 'WooCommerce', icon: '🛍️' },
                
                { name: 'Google Analytics', icon: '📊' },
                { name: 'Keyword Research', icon: '🔍' },
                { name: 'Link Building', icon: '🔗' },

            ],
        },
        {
            title: 'Digital product design ',
            description: 'Optimize your website for search engines and increase your online visibilityBenefit from good digital product design and create intuitive products that increase user engagement and support business objectives..',
            image: Img2,  
            technologies: [
                { name: 'Google Analytics', icon: '📊' },
                { name: 'Keyword Research', icon: '🔍' },
                { name: 'Link Building', icon: '🔗' },
                { name: 'Shopify', icon: '🛒' },
                { name: 'Magento', icon: '💳' },
                { name: 'WooCommerce', icon: '🛍️' },
            ],
        },
    ];

    return (
        <div className="min-h-screen bg-white">
            <main className="w-11/12 max-w-[1600px] mx-auto mt-12">
                <div className="text-sm text-gray-500 mb-12">
                    Services
                </div>

                <div className="grid grid-cols-1 gap-16">
                    {services.map((service, index) => (
                        <div key={index} className="flex flex-row items-center p-10">
                           
                            <div className="w-1/3">
                                <div className="rounded-lg overflow-hidden">
                                    <img
                                        src={service.image}  
                                        alt={service.title}
                                        className="w-[50vw] h-[60vh] object-cover"
                                    />
                                </div>
                            </div>

                          
                            <div className="flex flex-col items-center justify-center ml-8 w-1/3 text-center">
                                <h1 className="text-6xl font-bold">{service.title}</h1>
                                <p className="text-lg text-justify text-black-700 mt-14">{service.description}</p>
                            </div>

                            {/* Icon Section */}
                            <div className="flex flex-wrap justify-end w-1/3 space-x-1">
                                {service.technologies.map((tech, techIndex) => (
                                    <div
                                        key={techIndex}
                                        className="w-10 h-12 flex items-center justify-center text-2xl"
                                        title={tech.name}
                                    >
                                        {tech.icon}
                                    </div>
                                ))}
                                <button className="bg-red-600 mt-40 text-white px-6 py-3 transition-transform transform hover:scale-105">
                                    Read More
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};

export default Servicecard;
