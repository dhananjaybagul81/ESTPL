import React from 'react'

const Heroes = () => {
  return (
    <div className="flex h-full bg-[#edf2f3] w-11/12  max-w-[1600px] mx-auto">
      <div className="flex-1 p-10 flex flex-col justify-start">
        <h1 className="text-8xl font-bold leading-tight">
          <span>Our Services</span>
        </h1>

      </div>
    </div>
  )
}

export default Heroes;