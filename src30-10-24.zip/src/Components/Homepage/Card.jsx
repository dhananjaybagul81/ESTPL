import React from 'react'
import Img1 from "../../assets/bg1.png";
import Img2 from "../../assets/bg2.png";


const Card = () => {
  return (
    <div className='flex flex-col justify-between w-12/12  max-w-[1600px] mx-auto  p-8 h-[120vh] mt-36 relative'>

   
      <div className=' bg-white border border-red-600  z-1 radius-lg w-1/2 h-[110vh] transition-transform hover:-rotate-2 active:-rotate-1'>
        <img src={Img1} alt="Illustration" className="w-[700px] h-auto object-cover  px-8 py-8" />
        <p className='font-bold text-[40px] transition-transform hover:text-red-500 p-8 '>
          Custom illustration builder: from great idea to successful product!
        </p>
        <h4 className='p-8'>ITG Case Study</h4>
        <button className="mt-4  text-black border border-black 1x px-8 py-2 ml-8  rounded">SaaS Development</button>
      </div>

      
      <div className=' bg-white absolute top-96 right-0 border border-black w-1/2 h-[110vh]  z-0 transition-transform hover:-rotate-2 active:-rotate-3'>
        <img src={Img2} alt="E-commerce platform" className="w-[700px] h-auto object-cover  px-8 py-8" />
        <p className='font-bold text-[40px] transition-transform hover:text-red-500 p-8'>
          An enterprise e-commerce platform that calculates per-order business value in real-time
        </p>
        <h4 className='p-8'>Optimize marketing expenses against the real business value, all in one tool</h4>
        <button className="mt-4 border border-black 1x  text-black px-4 py-2  ml-8 rounded">SaaS Development</button>
      </div>

    </div>
  )
}

export default Card;
