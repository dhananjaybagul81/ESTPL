import React from 'react';

const Ourclient = () => {
    return (
        <div className='flex flex-col h-full bg-white w-11/12 mt-96 max-w-[1600px] mx-auto'>
            <h1 className='font-semibold text-blue-500 text-[70px] mb-12 text-left'>Our clients are:</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full  ">
                <div className="bg-blue-100 p-6 rounded-lg shadow-lg mt-4">
                    <h1 className='font-bold text-lg mb-8'>Businesses</h1>
                    <p>Inklocker - a fusion between printing expertise and technology, allowing local DTG print shops and the companies that use them to work seamlessly to do what they do best – print and sell.</p>
                </div>
                <div className="bg-blue-100 p-6 rounded-lg shadow-lg mt-4">
                    <h1 className='font-bold text-lg mb-8'>Creative Projects</h1>
                    <p>ITG Builder - an online illustrations builder that enables designers and marketers to create illustrations tailored to their specific needs in just a few clicks.</p>
                </div>
                <div className="bg-blue-100 p-6 rounded-lg shadow-lg mt-4">
                    <h1 className='font-bold text-lg mb-8'>Startups</h1>
                    <p>Caree - a Sweden-based startup providing a SaaS patient care platform for doctors and patients. Allows for practice management with the digital availability of electronic health records (EHR).</p>
                </div>
                <div className="bg-blue-100 p-6 rounded-lg shadow-lg mt-4">
                    <h1 className='font-bold text-lg mb-8'>SaaS Companies</h1>
                    <p>Infograto - making your presentation stand out has never been this easy. Infograto lets users create fun and engaging video presentations tailored to a specific theme.</p>
                </div>
            </div>
        </div>
    );
}

export default Ourclient;
