import React from 'react';

const Ourcross = () => {
    return (
        <div className="flex items-center justify-center  max-w-[1600px] w-11/12 mx-auto">
            {/* Container for "Estpl" and the paragraph */}
            <div className="flex-1 text-center">
                
                <span className="block w-full text-[30px] leading-[1] mb-4">
                    /
                </span>

                {/* "Estpl" Heading */}
                <h1 className="text-[350px] font-bold leading-none">
                    ESTPL
                </h1>

                
                <div className="mt-40 max-w-lg mx-auto p-8 bg-white  shadow-lg border border-gray-200 left-3">
                    <p className="text-xl text-left">
                        Our cross-functional development team has everything, <br />
                        you need to build, launch, <br />
                        and grow your rocket!
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Ourcross;
