import React, { useState } from 'react';
import { FaFacebook, FaLinkedin, FaGithub } from 'react-icons/fa';

const Contactus = () => {
    const [selectedCardIndex, setSelectedCardIndex] = useState(0);

    const cards = [
        { id: 1, name: "Maxim L.", paragraph: "Their organization and quality of work were impressive." },
        { id: 2, name: "John Doe", paragraph: "I am John Doe, a software developer." },
        { id: 3, name: "Jane Smith", paragraph: "I am Jane Smith, a project manager." },
        { id: 4, name: "Alice Johnson", paragraph: "I am Alice Johnson, a UI/UX designer." },
        { id: 5, name: "Bob Brown", paragraph: "I am Bob Brown, a backend developer." },
        { id: 6, name: "Charlie White", paragraph: "I am Charlie White, a data scientist." }
    ];

    const handleClick = () => {
        setSelectedCardIndex((prevIndex) => (prevIndex + 1) % cards.length);
    };

    return (

        
        <div className="p-10 mt-2 bg-[#edf2f3] w-[100vw] max-w-[1600px] mx-auto">
            <div className='items-start p-8 justify-start'>
            <h1 className="text-[250px] font-bold text-start leading-none">CONTACT <br /> US</h1>

            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 mt-14">
                <div
                    onClick={handleClick}
                    className="bg-white p-8 ml-8 rounded-lg shadow-lg border border-black mx-auto cursor-pointer transition-transform transform hover:scale-105"
                    style={{ height: '150px', width: '100%', maxWidth: '400px' }}
                >
                    <div className="flex items-center mb-2">
                        <img src="/api/placeholder/48/48" alt="User" className="w-12 h-12 rounded-full mr-2" />
                        <div>
                            <h3 className="text-lg font-semibold">{cards[selectedCardIndex].name}</h3>
                        </div>
                    </div>
                    <p className="text-gray-600 text-sm">"{cards[selectedCardIndex].paragraph}"</p>
                </div>

                <div className="flex flex-col justify-between">
                    <div className="flex justify-between mt-4 items-center mb-4">
                        <div className="text-center">
                            <h1 className="text-5xl md:text-8xl font-bold">80+</h1>
                            <h4 className="text-lg">Success Projects</h4>
                        </div>
                        <div className="text-center">
                            <h1 className="text-5xl md:text-8xl font-bold">8+</h1>
                            <h4 className="text-lg">Years of Experience</h4>
                        </div>
                    </div>

                    <div className="mt-4">
                        <p className="text-lg md:text-[24px] text-gray-700">
                            Our clients were featured in: <br />
                            <strong>TechCrunch, Forbes</strong>
                        </p>
                    </div>

                    <div className="text-start mt-12">
                        <h1 className="text-3xl md:text-5xl font-semibold mb-2">Let's get acquainted!</h1>
                        <button className="bg-red-600 mt-4 text-white px-6 py-3 transition-transform transform hover:scale-105">
                            SHARE YOUR IDEA WITH US
                        </button>
                    </div>
                </div>
            </div>

            <footer className=" py-16  mt-16">
                <div className="w-11/12 max-w-[1600px] mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                      
                        <div>
                            <div className="flex items-center mb-6">
                                <img src="/api/placeholder/40/40" alt="ESTPL Logo" className="mr-2" />
                                <span className="font-bold text-xl">ESTPL</span>
                            </div>
                            <div className="flex gap-4">
                                <FaFacebook className="w-6 h-6 text-gray-600 hover:text-gray-800 cursor-pointer" />
                                <FaLinkedin className="w-6 h-6 text-gray-600 hover:text-gray-800 cursor-pointer" />
                                <FaGithub className="w-6 h-6 text-gray-600 hover:text-gray-800 cursor-pointer" />
                            </div>
                        </div>

                       
                        <div>
                            <h3 className="font-bold mb-4">Industries</h3>
                            <ul className="space-y-2">
                               
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">Industry 1</a></li>
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">Industry 2</a></li>
                            </ul>
                        </div>

                      
                        <div>
                            <h3 className="font-bold mb-4">Company</h3>
                            <ul className="space-y-2">
                                
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">About Us</a></li>
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">Careers</a></li>
                            </ul>
                        </div>

                      
                        <div>
                            <h3 className="font-bold mb-4">Resources</h3>
                            <ul className="space-y-2">
                                {/* Add resources links here */}
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">Blog</a></li>
                                <li><a href="#" className="text-gray-600 hover:text-gray-800">Help Center</a></li>
                            </ul>
                        </div>
                    </div>

                    {/* Copyright */}
                    <div className="text-sm text-gray-600">
                        © 2024 ESTPL™
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default Contactus;
