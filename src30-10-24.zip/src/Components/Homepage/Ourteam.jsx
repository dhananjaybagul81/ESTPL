import React from 'react';
import { GrGraphQl } from "react-icons/gr";
import { IoLogoVue } from "react-icons/io5";
import { FaReact, FaAws } from "react-icons/fa6";
import { RiNextjsFill } from "react-icons/ri";
import { TbBrandReactNative } from "react-icons/tb";
import { IoLogoNodejs } from "react-icons/io5";
import { BiLogoPostgresql } from "react-icons/bi";

const Ourteam = () => {
    return (
        <div className=' p-10 mt-2  bg-[#edf2f3] w-11/12  max-w-[1600px] mx-auto'>
            
            <div className='flex flex-col md:flex-row mt-10'>
                <div className='flex-1'>
                    <h1 className='text-[50px] font-bold'>
                        OUR TEAM USES
                        <span className='text-pink-600'> THE BEST</span>
                        <span className='text-blue-600'> DEVELOPMENT</span>
                        <span className='text-pink-600 px-1'> PRACTICES</span>
                        AND
                        <span className='text-blue-600 px-1'> THE LATEST TECHNOLOGY</span>
                    </h1>
                </div>
                <div className='flex-1 mt-4 md:mt-0 md:ml-8'>
                    <p className='text-[20px] font-semibold text-justify'>
                        Modern but proven tools speed up the development process and increase your project’s effectiveness, feasibility, and investment appeal. Competitive technology combined with our cross-functional development team and flexible development methodologies will get you the results you want, faster.
                    </p>
                </div>
            </div>

          
            <div className='relative grid grid-cols-1 w-full h-[70vh] top-20 mb-10 p-4 rounded-lg'>
                <div className='absolute top-0 right-80 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-red-700'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <GrGraphQl className='mr-2' /> GraphQL
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        Give clients the power to get exactly what they asked for, make it easier to evolve APIs over time, and enable powerful developer tools.
                    </p>
                </div>

                <div className='absolute left-28 top-28 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <IoLogoVue className='mr-2' /> Vue.js
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        A progressive JavaScript web framework that enables better, faster results with great performance and lower costs.
                    </p>
                </div>

                <div className='absolute top-60 right-4 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-red-700'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <FaReact className='mr-2' /> React.js
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        The library for web and native user interfaces. It helps to seamlessly combine components written by independent teams.
                    </p>
                </div>
            </div>

          
            <div className='relative grid grid-cols-1 w-full bottom-10 h-[70vh] mb-10 p-4 rounded-lg flex-1'>
                <div className='absolute top-0 left-8 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <RiNextjsFill className='mr-2' /> Next.js
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        A React framework for building full-stack web applications, offering additional features and optimizations.
                    </p>
                </div>

                <div className='absolute top-1/2 right-80 transform -translate-x-1/2 -translate-y-1/2 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <TbBrandReactNative className='mr-2' /> MongoDB
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        Support transactions, search, analytics, and mobile uses with a common query interface developers love.
                    </p>
                </div>

                <div className='absolute top-60 right-12 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <IoLogoNodejs className='mr-2' /> Node.js
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        Lightweight and efficient, perfect for data-intensive real-time applications running across distributed devices.
                    </p>
                </div>
            </div>

           
            <div className='relative grid grid-cols-1 w-full bottom-20 h-[70vh] mb-10 p-4 rounded-lg'>
                <div className='absolute top-64 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <BiLogoPostgresql className='mr-2' /> PostgreSQL
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        A powerful, open-source object-relational database system with a strong reputation for reliability and performance.
                    </p>
                </div>

                <div className='absolute top-32 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4'>MongoDB</h1>
                    <p className='text-lg leading-relaxed'>
                        Support transactions, search, analytics, and mobile uses with a common query interface developers love.
                    </p>
                </div>

                <div className='absolute top-60 right-12 bg-gray-100 w-[400px] h-[250px] p-8 rounded-lg shadow-lg border border-black'>
                    <h1 className='text-[30px] font-bold mb-4 flex items-center'>
                        <FaAws className='mr-2' /> AWS
                    </h1>
                    <p className='text-lg leading-relaxed'>
                        Lightweight and efficient, perfect for data-intensive real-time applications running across distributed devices.
                    </p>
                </div>
            </div>
            
        </div>
    );
};

export default Ourteam;
