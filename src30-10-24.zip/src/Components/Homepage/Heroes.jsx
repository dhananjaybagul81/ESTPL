import React, { useState } from 'react';

const Heroes = () => {
  const [selectedCardIndex, setSelectedCardIndex] = useState(0);

  const cards = [
    { id: 1, name: "Maxim L.", paragraph: "Their organization and quality of work were impressive." },
    { id: 2, name: "John Doe", paragraph: "I am John Doe, a software developer." },
    { id: 3, name: "Jane Smith", paragraph: "I am Jane Smith, a project manager." },
    { id: 4, name: "Alice Johnson", paragraph: "I am Alice Johnson, a UI/UX designer." },
    { id: 5, name: "Bob Brown", paragraph: "I am Bob Brown, a backend developer." },
    { id: 6, name: "Charlie White", paragraph: "I am Charlie White, a data scientist." }
  ];

  const handleClick = () => {
    
    setSelectedCardIndex((prevIndex) => (prevIndex + 1) % cards.length);
  };

  return (
    <div className="flex h-full bg-white w-11/12  max-w-[1600px] mx-auto">
      {/* Left Side Content */}
      <div className="flex-1 p-10 flex flex-col justify-start">
        <h1 className="text-7xl font-bold leading-tight">
          <span className="block">TRUSTED</span>
          <span className="block">DEVELOPMENT</span>
          <span className="block">PARTNERS</span>
        </h1>
        <p className="mt-6 text-xl text-gray-600">
          Use the industry's best practices to guide your project to success!
        </p>
        <button className="mt-8 px-8 py-4 bg-red-500 text-white text-lg font-semibold rounded-md hover:bg-red-600 transition duration-300 w-max">
          BOOK A FREE CONSULTATION
        </button>
      </div>

      
      <div className="flex-1 p-10 flex flex-col justify-start mt-10">
        
        <div className="flex gap-4">
          
          <div className="p-4 rounded-lg flex-1 text-center">
            <h2 className="text-3xl font-bold">
              Clutch <span className="text-red-500">★ 5.0</span>
            </h2>
            <p className="mt-2 text-gray-600">
              We're recognized as one of the leading software development companies in the Netherlands.
            </p>
          </div>

          <div
            onClick={handleClick}  
            className="bg-white p-6 rounded-lg shadow-lg border border-black flex-1 h-[200px] cursor-pointer transition-transform transform hover:scale-105"
          >
            <div className="flex items-center mb-4">
              <img src="/api/placeholder/48/48" alt="User" className="w-12 h-12 rounded-full mr-4" />
              <div>
                <h3 className="text-xl font-semibold">{cards[selectedCardIndex].name}</h3>
              </div>
            </div>
            <p className="text-gray-600">"{cards[selectedCardIndex].paragraph}"</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Heroes;
