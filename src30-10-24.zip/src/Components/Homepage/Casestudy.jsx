import React from 'react';

const Casestudy = () => {
  return (
    <div className='relative w-11/12  max-w-[1600px] mx-auto flex flex-col items-start p-10'>
      
    
      <h1 className='font-extrabold text-[200px] leading-none'>
        CASE<br />STUDIES
      </h1>

     
      <div className='absolute bottom-[-150px] right-20'>
        <p className='text-[40px] font-bold'>
          Take a <span className='text-blue-400'>closer look</span> at some of the <br />
          <span className='text-blue-400'>projects</span> we worked on!
        </p>
      </div>
    </div>
  );
}

export default Casestudy;
