import React from 'react';

const Expertise = () => {
    return (
        <div className='h-full bg-black w-full mt-8 max-w-[1700px] mx-auto px-20 py-20'>
           <div className='flex justify-end  mt-20 max-w-5xl items-end space-x-2  '>
                <p className='font-bold text-[40px] text-white  '>
                Devstark - a one-stop shop for your development needs, whatever they are. Whether it’s via web, software, or mobile, we’re here to help your ideas connect with online users.

                </p>
            </div>

            <div className='relative grid grid-cols-1 md:grid-cols-2 gap-8 mt-20'>
                <div className='pr-4'>
                    <h2 className='text-white font-bold text-4xl mb-4'>Expertise</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        We have 8+ years of experience in creating easy-to-use, fast, technologically sound applications and 80+ successful and innovative projects under our belt.
                    </p>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        With us, you’re in good hands.
                    </p>
                </div>

                <div className='pl-4 mt-60'>
                    <h2 className='text-white font-bold text-4xl mb-4'>Versatility</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        Our personal approach allows us to meet your project’s unique needs, recommend the right tech and processes, and use our knowledge to help you reach a positive outcome in your web development story.
                    </p>
                </div>
            </div>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-8 mt-14'>
                <div className='pr-4'>
                    <h2 className='text-white font-bold text-4xl mb-4'>International</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        The DS global team is ready to work with you wherever you are. Our experience working with clients worldwide has taught us that sound business practices and humanity are universal regardless of timezone or language.
                    </p>
                </div>

                <div className='pl-4 mt-60'>
                    <h2 className='text-white font-bold text-4xl mb-4'>Flexibility</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        We value adaptability and involvement in our development process. We construct flexible and scalable applications in close collaboration with our development team and give feedback from the earliest stages of development.
                    </p>
                </div>
            </div>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-8 mt-14'>
                <div className='pr-4'>
                    <h2 className='text-white font-bold text-4xl mb-4'>Modern tech stack and development process</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        Our skilled cross-functional team is driven to use the best development practices and the latest tech on the market.
                    </p>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        This dynamic combination lets us deliver the results you want in record time.
                    </p>
                </div>

                <div className='pl-8 mt-60'>
                    <h2 className='text-white font-bold text-4xl mb-4'>Hands-on personal experience with SAAS startups</h2>
                    <p className='text-gray-300 text-lg leading-relaxed'>
                        When it comes to SaaS development, we've done it all. We understand the problems and needs of startups, from the early development stages to post-launch activities.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Expertise;
