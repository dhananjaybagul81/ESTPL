import React from 'react';

const Weoffer = () => {
    return (
        <div className='mt-24 bg-black text-white w-12/12  max-w-[1600px] mx-auto p-4'>
            <div className='flex justify-end h-[50vh] mt-20'>
                <p className='font-bold text-[40px] pl-20'>
                    We use <span className='text-blue-600'>a</span> <span className='text-pink-600'>customer-oriented</span> <br />
                    <span className='text-blue-600'>approach</span> to build platforms <br />that align with our clients’ <br />business goals. Your project’s <br />
                    success is our top priority!
                </p>
            </div>
            <div className='flex flex-col justify-start p-4'>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Our Services</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>
                            Work with a development team attuned to your business goals. We offer a full development cycle, and a scalable cross-functional team that supports your project at every stage.
                        </p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Frontend Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda, error.</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Backend Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit, illo architecto repellat adipisci molestiae aperiam facere incidunt impedit deleniti vel?</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Mobile Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab facilis ullam similique sed architecto maiores excepturi tempore quia culpa incidunt?</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Digital Product Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus, magni!</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Quality Service</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa, ad?</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>AI Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequatur, incidunt!</p>
                    </div>
                </div>
                <span>////////////////////////////////////////////////</span>
            </div>
            <div className='bg-black w-full flex justify-center '>
                <div className='grid grid-cols-1 md:grid-cols-2 bg-[#1F2228] h-[70vh] w-[80%] items-center p'>
                    <div className='flex flex-1 justify-center items-center'>
                        <img src="" alt="Automation" />
                    </div>
                    <div className='flex flex-col justify-center items-start'>
                        <h1 className='text-[64px] font-extrabold'>Does your business need automation?</h1>
                        <h3 className='text-[18px]'>Contact us for a free consultation. Let's talk!</h3>
                        <button className='bg-red-600 text-white py-2 px-4 mt-4 rounded transition duration-300 hover:bg-red-700'>LET'S TALK!</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Weoffer;
