import React from 'react'

const Customer = () => {
  return (
   <div className=' flex justify-start h-[50vh] mt-5 border w-11/12  max-w-[1600px] mx-auto'>
    <p className=' font-bold text-[40px]  pl-20'>We use <span className='text-blue-600'>a</span> <span className='text-pink-600'>customer-oriented</span> <br />  <span className=' text-blue-600'>approachspan</span> to build platforms <br />that align with our clients’ <br />business goals. Your project’sbr
     <br />success is our top priority!
    </p>
   </div>
  )
}

export default Customer;