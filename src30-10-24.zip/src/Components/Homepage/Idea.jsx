import React from 'react';

const Idea = () => {
    return (
        <div className='grid grid-cols-1 md:grid-cols-2 mx-auto pl-40 pr-40 h-[80vh] w-[90vw]  bg-[#edf2f3] shadow-lg'>
           
            <div className='flex flex-col justify-center p-4 '>
                <h1 className='font-bold text-[40px] md:text-[60px]'>Have a brilliant idea?</h1>
                <h3 className='font-semibold text-[20px] md:text-[30px]'>We’ll help you make it a reality.</h3>
                <button className='mt-4 bg-red-500 text-white p-2 rounded-md'>
                    CLICK FOR A FREE CONSULTATION
                </button>
            </div>
            
            
            <div className='flex justify-center items-center'>
                <img 
                    src="https://via.placeholder.com/300" 
                    alt="Diamond" 
                    className='w-full h-auto max-w-[300px]'
                />
            </div>
        </div>
    );
}

export default Idea;
