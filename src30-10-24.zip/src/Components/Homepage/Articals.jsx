import React from 'react';

const Articles = () => {
    const articles = [
        {
            id: 1,
            title: "LAW AND AI",
            description: "Artificial intelligence is reshaping how the legal field is doing business. Learn how AI can improve workflows and save time and money for lawyers and their clients.",
            image: "/api/placeholder/600/400",
            author: "Viktoriya Poligenko",
            bgColor: "bg-blue-600"
        },
        {
            id: 2,
            title: "Speed up development with Payload CMS",
            description: "Find out how Payload CMS speeds up the development process of not only websites, but also web apps without compromising on product quality!",
            image: "/api/placeholder/600/400",
            author: "Viktoriya Poligenko",
            bgColor: "bg-purple-600"
        },
        {
            id: 3,
            title: "Jamstack - deciphered",
            description: "You've probably heard the term 'Jamstack' used a lot lately, but what does it mean? Jamstack is a modern web development architecture designed to provide better performance, more security, lower scaling costs, and a smoother developer experience.",
            image: "/api/placeholder/600/400",
            author: "Viktoriya Poligenko, Mariana Neagu",
            bgColor: "bg-red-600"
        }
    ];

    return (
        <div className="w-11/12 max-w-[1600px] mx-auto mt-20">
            <h1 className="text-5xl text-blue-500 font-semibold mb-12">Read our latest articles:</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3  gap-8">
                {articles.map((article) => (
                    <div
                        key={article.id}
                        className="group flex flex-col rounded-2xl overflow-hidden transition-transform duration-300 hover:-translate-y-2"
                    >

                        <div className="relative h-80 overflow-hidden">
                            <div className={`absolute inset-0 ${article.bgColor} opacity-75`}></div>
                            <img
                                src={article.image}
                                alt={article.title}
                                className="w-full h-full object-cover"
                            />
                        </div>


                        <div className="flex flex-col flex-grow p-8 bg-white shadow-lg">
                            <h2 className="text-2xl font-bold mb-6">{article.title}</h2>
                            <p className="text-gray-600 mb-8 flex-grow">{article.description}</p>

                            <div className="flex items-center mt-4">
                                <img
                                    src="/api/placeholder/40/40"
                                    alt={article.author}
                                    className="w-10 h-10 rounded-full mr-3"
                                />
                                {/* <span className="text-sm text-gray-500 mt-24">{article.author}</span> */}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Articles;