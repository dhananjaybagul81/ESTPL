import React from 'react';

const Ourservices = () => {
    return (
        <div className='  grid grid-cols-1 md:grid-cols-2 w-11/12  max-w-[1600px] mx-auto'>
           
            <div className='col-span-1 flex justify-center items-center'>
                <img
                    src="https://via.placeholder.com/300" // Replace with your image URL
                    alt="Service"
                    className='w-full h-auto max-w-[300px] rounded-lg' // Responsive and styled
                />
            </div>

            {/* Second Column: Information */}
            <div className='col-span-1 flex flex-col justify-start p-4'>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Our Services</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>
                            Work with a development team attuned to your business goals. We offer a full development cycle, and a scalable cross-functional team that supports your project at every stage.
                        </p>
                    </div>
                </div>
                <span>//</span>

                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Frontend Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda, error.</p>
                    </div>
                </div>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Backend Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit, illo architecto repellat adipisci molestiae aperiam facere incidunt impedit deleniti vel?</p>
                    </div>
                </div>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Mobile Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab facilis ullam similique sed architecto maiores excepturi tempore quia culpa incidunt?</p>
                    </div>
                </div>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Digital Product Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus, magni!</p>
                    </div>
                </div>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>Quality Service</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa, ad?</p>
                    </div>
                </div>
                <span>//</span>
                <div className='grid grid-cols-1 md:grid-cols-2 mb-8 mt-8'>
                    <div className='flex flex-col'>
                        <h1 className='font-bold text-[30px] hover:text-red-600 transition duration-300'>AI Development</h1>
                    </div>
                    <div className='flex flex-col md:ml-4'>
                        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequatur, incidunt!</p>
                    </div>
                </div>
                <span>//</span>
            </div>
        </div>
    );
}

export default Ourservices;
