import React from 'react';

const Checkout = () => {
    return (
        <div className='grid grid-cols-1 md:grid-cols-2 mx-auto pl-40 pr-40 h-full p-8 w-[90vw]  mt-20 bg-[#edf2f3] shadow-lg'>
           
            <div className='flex flex-col justify-start  p-10 mb-10  '>
               <p className='flex justify-start font-extrabold text-[50px] leading-tight'>
               Check out some of our projects in our Case Studies section
               </p>
               <h1 className='font-semibold text-2xl'>and join our partner’s success stories!</h1>
                <button className='mt-8 bg-red-500 text-white p-2 w-[20vw] rounded-md'>
                    GO TO CASE STUDIES
                </button>
            </div>
            
            
            <div className='flex justify-center items-center'>
                <img 
                    src="https://via.placeholder.com/300" 
                    alt="Diamond" 
                    className='w-full h-auto max-w-[300px]'
                />
            </div>
        </div>
    );
}

export default Checkout;
