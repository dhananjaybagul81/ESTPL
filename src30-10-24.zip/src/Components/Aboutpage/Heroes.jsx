import React from 'react'

const Heroes = () => {
    return (
        <div className="flex h-[50vh] bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto relative">


             <div className="max-w-2xl  mt-20 text-justify ">
                <h1 className="text-[60px] font-extrabold leading-tight">
                Transforming ideas into quality digital products <span className='text-blue-400'>since 2015</span> 

                </h1>
            </div>


            <div className="flex flex-col mt-56 w-[40vw]  p-10 absolute right-0">

                <div className="flex justify-end items-end">
                    <p className="text-2xl  p-4">
                    At Devstark we believe that technology exists for people’s joy and comfort. Knowing that we are a part of this joy-bringing mechanism motivates us to do our best.                     </p>
                   
                </div>
            </div>
        </div>
    )
}

export default Heroes