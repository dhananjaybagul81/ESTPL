import React from 'react';

const Wework = () => {
  return (
    <div className="flex flex-col items-end w-[100vw] max-w-7xl mx-auto px-6 mt-20">
      <div className="max-w-4xl md:w-2/3 lg:w-1/2 justify-end  ">
       
        <p className='mb-8 text-4xl'>We work to help people take advantage of a more comfortable and easy lifestyle by creating products and services that improve the human experience.
        </p>
        <p className="text-4xl md:text-xl right-0 justify-end items-end text-gray-700">
          For years we have been helping entrepreneurs turn their business ideas into useful digital products. We guide each project with care and attention to detail to make sure our partners reach a positive outcome.
        </p>
      </div>
    </div>
  );
};

export default Wework;