import React from 'react';
import Img2 from "../../assets/Abouti1.png";

const Ourteam = () => {
    return (
        <div className="flex flex-col min-h-screen bg-[#0f1115] w-full">

            <div className="flex flex-col items-center justify-center flex-grow px-4 py-16">


                <div className="max-w-4xl text-justify mt-14  space-y-12 mb-8">
                    <p className="text-white text-4xl leading-relaxed">
                        Founded by two development engineers our agile team enjoys a bureaucracy-free and results-oriented working climate.                    </p>

                </div>

                <div className='flex flex-col  items-center'>
                    <img src={Img2} alt="About ESTPL" />
                </div>
            </div>
        </div>
    );
};

export default Ourteam;