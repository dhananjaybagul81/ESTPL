import React from 'react';

const Card = () => {

  
    return (
        <div className="flex h-full bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto relative">
            <div className="max-w-4xl p-8 mt-10  ml-auto ">
                <p className="text-gray-800 text-6xl  font-semibold leading-snug">
                    Everyone at Devstark is in IT for the love of it! Shared principles and values guide our cross-functional development team.
                </p>
            </div>

           
        </div>
    );
}

export default Card;
