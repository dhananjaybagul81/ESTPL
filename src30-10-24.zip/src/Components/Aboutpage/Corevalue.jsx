import React from 'react';

const Corevalue = () => {
    return (
        <div className="flex h-[100vh] bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto relative">
            <div className="max-w-4xl p-8 mt-20 text-justify mb-40"> {/* Adjusted bottom margin */}
                <h1 className="text-[350px] font-extrabold leading-none">
                    CORE <br /> <span className='text-blue-400'>VALUES</span>
                </h1>
            </div>

            
        </div>
    );
}

export default Corevalue;
