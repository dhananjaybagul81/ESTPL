import React from 'react';

const Card1 = () => {
    return (
        <div className="flex h-full bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto p-8">
            <div className="grid grid-cols-2 w-[50vw] border border-red-900 ">
                
              
                <div className="flex flex-col justify-center items-center   p-8">
                    <h1 className="text-3xl font-bold mb-4">Honesty and Integrity</h1>
                    <p className="text-lg m-w-4xl">
                        We believe that building trusting, long-term relationships with our partners is the best way to do business. 
                        That is why everything we do is built on honest communication and integrity.
                    </p>
                </div>
                
               
                <div className=" right-20 max-w-md  p-8">
                    <h1 className="text-3xl font-bold mb-4">Our Partner’s Success is Our Success</h1>
                    <p className="text-lg">
                        A proactive approach focused on our partners' prosperity and their user’s satisfaction is the way for everyone to win. 
                        That is why we carefully guide our partner’s projects to reach a positive outcome ASAP.
                    </p>
                </div>

            </div>
        </div>
    );
}

export default Card1;
