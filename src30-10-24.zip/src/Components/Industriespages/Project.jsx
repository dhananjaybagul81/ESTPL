import React from 'react';
import bgimg from "../../assets/Servicebg.png";

const Project = () => {
  
    const services = [
        {
            title: 'Eduction',
            description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda, error.',
            projectName: '10'
        },
        {
            title: 'Healthcare',
            description: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Velit, illo architecto repellat adipisci molestiae aperiam facere incidunt impedit deleniti vel?',
            projectName: '25'
        },
        {
            title: 'Transport',
            description: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab facilis ullam similique sed architecto maiores excepturi tempore quia culpa incidunt?',
            projectName: '35'
        },
        {
            title: 'Travel ',
            description: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus, magni!',
            projectName: '40'
        },
      
    ];

    return (
        <div className=' bg-black text-white w-full max-w-[1600px] mx-auto p-4'>
            <div className='flex flex-col items-center  h-[50vh] mt-20'>
                <p className='font-bold text-[40px] pl-20  text-justify'>
                    We work to help people take advantage <br />
                    of a more comfortable and easy <br />
                    lifestyle by creating products and <br />
                    services that improve the human experience.
                </p>
                <div className='text-[24px] mt-8 text-justify'>
                    <p>
                        For years we have been helping entrepreneurs <br />
                        turn their business ideas into useful digital products. <br />
                        We guide each project with care and attention <br />
                        to detail to make sure our partners reach a positive outcome.
                    </p>
                </div>
            </div>



            <div className='flex flex-col justify-center items-center p-4 mt-40'>



                {services.map((service, index) => (
                    <div key={index} className='grid grid-cols-3 mb-8 mt-8 items-center text-center pl-32'>
                        <div className='flex flex-col items-start justify-start '>
                            <h1 className='font-bold text-[60px] hover:text-red-600 transition duration-300'>{service.title}</h1>
                        </div>
                        <div className='flex flex-col items-center'>
                            <p>{service.description}</p>
                        </div>
                        <div className='flex flex-col items-end mr-8'>
                            <p className=' hover:text-red-600 transition duration-300 text-[40px]'>{service.projectName}</p> {/* Displaying project name */}
                        </div>
                    </div>
                ))}
            </div>
           
            <div className=" w-full max-w-[1600px] mx-auto mt-20">
                <div className='p-10 flex flex-col justify-start h-[100vh] border border-black'> 
                    <h1 className="text-6xl font-bold leading-tight text-left ml-8"> 
                        <span className='text-white'>Our entrusted <span className='text-pink-500'>partners</span></span>
                    </h1>
                    <img  src={bgimg} className=' p-5 mt-32'/>
                </div>
            </div>
    

        </div>
    );
}

export default Project;
