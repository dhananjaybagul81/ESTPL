import React from 'react';

const Slidenest = () => {
  return (
    <div className="flex h-full bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto">
      <div className='grid grid-cols-1 grid-flow-row  w-full mt-8'>
        <div className='border  p-4'>
          <h1 className='font-bold text-[70px]'>Industries we know in <br />and out to help your <br /> digital growth.</h1>
        </div>
        <div className='col-span-2 flex items-center justify-end p-4'>
          <p className='text-right text-[24px]'>

            Devstark's team leverages its vast knowledge in  these  <br />five industries to deliver the best digital expert advise <br />and developmentbr
            services on the market. </p>
        </div>
      </div>
    </div>
  );
}

export default Slidenest;
