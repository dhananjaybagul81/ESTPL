import React from 'react';
import Img1 from "../../assets/carrieri1.png";

const AboutEstpl = () => {
  return (
    <div className="flex flex-col min-h-screen bg-[#0f1115] w-full">
    
      <div className="flex flex-col items-center justify-center flex-grow px-4 py-16">

      <div className='flex flex-col  items-center'>
                <img src={Img1} alt="About ESTPL" />
            </div>
    
        <div className="flex items-center  mt-20 mb-16">
          <span className="text-blue-500 text-6xl font-semibold">About</span>
          <span className="text-white text-6xl font-semibold ml-3">Estpl</span>
        </div>

        
        <div className="max-w-4xl text-justify space-y-12">
          <p className="text-white text-2xl leading-relaxed">
            Estpl is a software development company and a product studio. 
            Products of our own help us learn and polish our skills to excel 
            in the projects we deliver to our partners.
          </p>

          <p className="text-white text-2xl leading-relaxed">
            Our diverse portfolio of products can range from mobile apps to web 
            applications, IoT technology, ML, AI-powered tech, image recognition 
            software, and VR, allowing us to experiment with various technologies 
            and explore new possibilities.
          </p>

          <p className="text-white text-2xl leading-relaxed">
            As a part of our team, you will work with challenging, sophisticated, 
            and innovative projects where we solve interesting problems using 
            cutting-edge tech stack and the world's best practices.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutEstpl;