import React from 'react';

const Estpl = () => {
    return (
        <div className="flex  mt-20 h-full w-full justify-center items-center mb-8">
            <div className="max-w-4xl text-justify space-y-12">
                <p className=" text-2xl leading-relaxed">
                <strong>Estpl</strong> is an  <strong>international IT company </strong> that provides innovative solutions to our partners. We are delighted that you are interested  <strong>in exploring career opportunities with us.</strong>
                </p>

                <p className=" text-2xl leading-relaxed">
                We are committed to creating a dynamic, inclusive work environment that fosters collaboration, innovation, and growth. People are at the heart of our business, and we strive to empower them by providing the resources and opportunities needed to succeed.
                </p>

               
            </div>
        </div>
    );
};

export default Estpl;
