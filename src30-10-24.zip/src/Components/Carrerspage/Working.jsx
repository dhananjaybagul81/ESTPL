import React from 'react'

const Working = () => {
  return (
    <div className="flex flex-col min-h-screen  w-full">
    
    <div className="flex flex-col items-center justify-center flex-grow px-4 py-16">

        <div className='flex items-start mb-20 '>
            <h1 className='text-7xl font-bold'><span className='text-blue-500'>Working</span> <span className=''>at Estpl</span></h1>
        </div>
      
      <div className="max-w-4xl text-justify space-y-12">
        <p className=" text-2xl leading-relaxed">
        Our fully remote international team enjoys a flexible working schedule and the freedom to work from anywhere you like. 
        </p>

        <p className="t text-2xl leading-relaxed">
        Flexible working hours mean you can start and finish your day at work at hours convenient for you as long as you get the job done. 
        </p>

        <p className=" text-2xl leading-relaxed">
        There are five days and 40 hours in our work week. Our team members enjoy paid vacations and flexible day-offs upon request.
        </p>
        <p className=" text-2xl leading-relaxed">
        Bureaucracy-free processes are at the core of our company. Our team communicates freely and openly while working on our common goal - delivering development services, we can be proud of.
        </p>
      </div>
    </div>
  </div>
  )
}

export default Working