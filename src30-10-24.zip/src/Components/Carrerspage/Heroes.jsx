import React from 'react'

const Heroes = () => {
    return (
        <div className="flex h-full bg-[#edf2f3] w-11/12 max-w-[1600px] mx-auto relative">


            <div className="flex-1 p-10 flex flex-col justify-start">
                <h1 className="text-6xl font-bold leading-tight">
                    ESTPL <br />
                    <span className='text-blue-500'>
                        career opportunities
                    </span>

                </h1>
            </div>


            <div className="flex flex-col mt-20 w-[40vw]  p-10 absolute right-4">

                <div className="flex justify-end items-end">
                    <p className="text-2xl font-bold  p-4">
                        Build your career in IT with us and become a part of our team!
                    </p>

                </div>
            </div>


          
        </div>
        
    )
}

export default Heroes;