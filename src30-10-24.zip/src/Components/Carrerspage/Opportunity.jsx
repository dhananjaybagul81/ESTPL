import React from 'react';
import Img2 from "../../assets/carrieri2.png";

const Opportunity = () => {
    return (
        <div className="flex flex-col min-h-screen bg-[#0f1115] w-full">

            <div className="flex flex-col items-center justify-center flex-grow px-4 py-16">

                <div className='flex flex-col  items-center'>
                    <img src={Img2} alt="About ESTPL" />
                </div>

                <div className="max-w-4xl text-justify mt-10">

                    <span className="text-blue-500 text-6xl font-semibold">Career

                    </span>
                    <span className="text-white text-6xl font-semibold ml-3">opportunities</span>
                </div>


                <div className="max-w-4xl text-justify mt-14  space-y-12">
                    <h1 className='font-bold  text-white text underline text-4xl'>Backend team-lead</h1>

                    <p className="text-white text-2xl leading-relaxed">
                        We're looking for a seasoned backend developer. As part of our team, you will work with challenging, sophisticated, and innovative projects where we solve interesting problems using cutting-edge tech stack and the world’s best practices.
                    </p>

                    <p className="text-white text-2xl leading-relaxed">
                        Tech-stack: JavaScript, Node.js, Apollo GraphQL, Gitlab. AWS (main): AWS ECS, AWS EC2, AWS IAM, AWS Systems Manager, AWS Batch, AWS Athena, AWS RDS (PostgreSQL), AWS Kinesis, AWS Kinesis Firehose, Amazon AppFlow, Amazon SQS, AWS Lambda, Amazon S3, Amazon EventBridge.
                    </p>


                </div>
            </div>
        </div>
    );
};

export default Opportunity;